# 🛡️ SentinelAI Threat Shield — Chrome / Edge Browser Extension

**SentinelAI Threat Shield** is a Manifest V3 browser extension that brings real-time AI security intelligence directly to citizen browsers. It features instant **Website URL Threat Checking** and **On-Page PDF Document Verification**.

---

## 🌟 Key Presentation Features

1. **🌐 Feature 1: Website URL Safety Guard & Real-Time Threat Analysis**
   - Automatically detects the active tab URL.
   - Communicates with SentinelAI backend (`POST /api/v1/analyze/full`) to evaluate website safety based on both domain structure and scraped web page content via Gemini AI.
   - Displays real-time threat levels (`SAFE`, `SUSPICIOUS`, `HIGH`, `CRITICAL`), threat risk score (0–100), scam category, risk indicators, and tactical recommendations.
   - Dynamic Extension Badge updates in real time on active tabs (`SAFE` in green, `WARN` in amber, `RISK` in red).

2. **📄 Feature 2: On-Page PDF Scanner & Advisory File Analyzer**
   - Allows drag-and-drop or file upload of PDF documents directly inside the popup UI.
   - Automatically injects an **"🛡️ AI Verify"** badge next to PDF links on any website.
   - Extracts phone numbers, UPI handles, currency amounts, scam variant classification, and actionable countermeasures from PDF advisories.

---

## 🚀 How to Install & Load Extension (Presentation Setup)

### Step 1: Open Extension Management Page in Browser
- **Google Chrome**: Navigate to `chrome://extensions/`
- **Microsoft Edge**: Navigate to `edge://extensions/`
- **Brave Browser**: Navigate to `brave://extensions/`

### Step 2: Enable Developer Mode
- Toggle the **"Developer mode"** switch in the top-right corner of the page.

### Step 3: Load Unpacked Extension
- Click the **"Load unpacked"** button.
- Select the `extension` folder:
  `c:\Users\Admin\Downloads\ET\ET\extension`

---

## 🧪 Presentation Demo Flow

1. **Backend Service Requirement**:
   - Ensure the SentinelAI FastAPI backend is running on `http://localhost:8000`.
   ```bash
   cd backend
   venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000
   ```

2. **Demonstrate Website URL Checking**:
   - Open any web page (e.g. `https://github.com/shravanbpatel954/etbackendcode` or a test site).
   - Click the **SentinelAI Shield** icon in your browser toolbar.
   - Click **"Analyze URL"**.
   - Show the live Threat Score, Category, Evidence, and Recommendations.

3. **Demonstrate On-Page PDF Scanning**:
   - Switch to the **"PDF Scanner"** tab in the extension popup.
   - Drag & drop a PDF document (or click to select a file).
   - Click **"Analyze PDF Safety"**.
   - Show extracted entities (Phone, UPI, Amount), scam summary, and recommendations.
